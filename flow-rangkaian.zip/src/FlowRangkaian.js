import "./stylesFlowRangkaian.css";

export default function FlowRangkaian() {
  return (
    <div className="background-flow">
      <div className="noisy">
        <div class="timeline">
          <div class="container right">
            <div class="content">
              <div className="JudulRangkaian">
                <p>HEALTH CHECK UP</p>
              </div>
              <div className="contentTglRangkaian">
                <div className="TanggalRangkaian">
                  <p>31 Oktober 2023</p>
                </div>
              </div>
            </div>
          </div>

          <div class="container right">
            <div class="content">
              <div className="JudulRangkaian">
                <p>WORK OUT WORKSHOP</p>
              </div>
              <div className="contentTglRangkaian">
                <div className="TanggalRangkaian">
                  <p>2 November 2023</p>
                </div>
              </div>
            </div>
          </div>

          <div className="BottomSection">
            <div class="container right ">
              <div class="content">
                <div className="JudulRangkaian">
                  <p>TALKSHOW</p>
                </div>
                <div className="contentTglRangkaian">
                  <div className="TanggalRangkaian">
                    <p>8 November 2023</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
